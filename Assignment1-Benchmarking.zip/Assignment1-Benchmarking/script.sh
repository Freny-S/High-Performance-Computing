#!/bin/bash
# ===== PBS OPTIONS =====
#PBS -N "MyJob"
#PBS -q mamba
#PBS -l nodes=1:ppn=16
g++ /Assignment1-Benchmarking/flopscode.cpp -fopenmp -march=native -mtune=native -mavx2 -std=c99 -std=gnu99
./a.out
