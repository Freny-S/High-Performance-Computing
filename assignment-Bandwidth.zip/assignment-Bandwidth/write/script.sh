#!/bin/bash
# ===== PBS OPTIONS =====
#PBS -N "WriteJob"
#PBS -q mamba
#PBS -l nodes=1:ppn=16
g++ write.cpp -fopenmp -march=native -mtune=native -mavx2 -std=c++11 -std=gnu++11
./a.out
