#!/bin/bash
# ===== PBS OPTIONS =====
#PBS -N "MyJob"
#PBS -q mamba
#PBS -l nodes=4:ppn=4
g++ /Assignment1-Benchmarking/iops.cpp -fopenmp -march=native -mtune=native -mavx2 -std=c++11 -std=gnu99
./b.out