#include<stdio.h>
#include <iostream>
#include<omp.h>
#include<time.h>
#include<sys/time.h>
#include<chrono>

using namespace std;

int main()
{
	const int n = 100000;
	int a[n];
	for(int i=0; i < n; i++)
	{
		a[i] = i;
	}
	int local_sum, sum;
	auto start=std::chrono::high_resolution_clock::now();

	#pragma omp parallel private(local_sum) shared(sum)
	{
		local_sum = 0;
		#pragma omp for schedule(static, 1)
		for(int i=0; i<n; i++)
		{	
			local_sum += a[i];
		}
		#pragma omp critical
		{	
			sum += local_sum;
		}
	}
	
	auto end=std::chrono::high_resolution_clock::now();
	auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
	std::cout<<duration.count();

	//cout<<"Sum should be: "<<(n*(n-1)/2)<<endl;
	cout<<"Sum is: "<<sum;
	
	//FTime = ((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec));
	

}
