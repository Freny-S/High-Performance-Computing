#!/bin/bash
# ===== PBS OPTIONS =====
#PBS -N "ReadJob"
#PBS -q mamba
#PBS -l nodes=1:ppn=16
g++ read.cpp -fopenmp -march=native -mtune=native -mavx2 -std=c++11 -std=gnu++11
./a.out
