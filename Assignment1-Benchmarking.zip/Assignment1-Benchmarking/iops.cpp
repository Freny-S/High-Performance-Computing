#include<stdio.h>
#include<immintrin.h>
#include<omp.h>
#include<time.h>
#include<sys/time.h>


int main()
{
	int thread = 1, loop = 1000 * 1000 * 1000;
	struct timeval start, end;
	float ITime = 0;
	int i = 0;

	register __m256i vec1 = _mm256_set_epi32(1, 2, 3, 4, 5, 6, 7, 8);
	register __m256i vec2 = _mm256_set_epi32(9, 2, 3, 4, 5, 6, 7, 8);
	register __m256i vec3 = _mm256_set_epi32(1, 1, 1, 1, 1, 1, 1, 1);
	register __m256i vec4 = _mm256_set_epi32(6, 5, 1, 2, 5, 6, 7, 8);
	
	gettimeofday(&start, NULL);

	#pragma omp parallel for default(shared)
	for(i = 0; i < loop; i++)
	{	
		if(i == 0)
		{
			thread = omp_get_num_threads();
		}
	__mm256i result1 = _mm256_add_epi32(vec1, vec2);
	__mm256i result2 = _mm256_add_epi32(vec3, vec4);
	__mm256i result3 = _mm256_sub_epi32(result1, result2);
	__mm256i result4 = _mm256_add_epi32(result1, result2);
	asm("");
	}
	
	gettimeofday(&end, NULL);

	ITime = ((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec));
	cout<<"Number of iops = %f per sec.\n"<<(4 * (float)loop * (float)thread * (256./32.) * 1000000) / ITime);

	return 0;

	

}